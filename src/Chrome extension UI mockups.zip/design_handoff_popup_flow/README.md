# Handoff: TWP Script Deployer — popup flow (option 3a)

## Overview

A redesign of the TWP Script Deployer Chrome extension popup (`src/popup/` in the
`TWP-Script-Deployer` repo). One 400 × 566 popup carries three views plus a modal
sheet:

1. **Library** — saved templates, select one, deploy it.
2. **Template editor** — a rail of the 10 TWP script pages + one editor pane.
3. **New template** — the same rail, empty, with a name field; save gated.
4. **Confirm / deploy sheet** — lists exactly which script pages will change, then
   reports per-page progress as `runRoutine()` walks them.

It replaces today's centered, system-font popup (stacked 10 textareas, `Run Routine`
with no confirmation) with a list-detail flow and an explicit pre-deploy confirmation.

## About the design files

`TWP Deployer Mockups.dc.html` (+ `support.js`, its runtime) is a **design
reference created in HTML** — a prototype of look and behavior, not production code
to copy. The task is to recreate it inside the existing extension: React 18 +
TypeScript + Vite, in `src/popup/`, keeping `chrome.storage.local` persistence,
`runRoutine()` from `src/scripts/run-routine.ts`, and the `TwpScriptTemplate` /
`TwpScriptPage` types unchanged. Only the popup UI layer changes.

Open the file in a browser. It contains three turns, newest first:

- **Turn 3 (`#3a`) — the design to build.**
- Turn 2 (`#2a`, `#2b`, `#2c`) — earlier explorations (2a and 2b were merged into 3a; 2c is a wider full-page console, out of scope).
- Turn 1 (`#1a`, `#1b`) — the current popup recreated from `App.css` / `ScriptLibrary.tsx` / `TemplateEditor.tsx`, for before/after comparison.

## Fidelity

**High-fidelity.** Final colors, typography, spacing and interaction states.
Recreate pixel-perfectly. All values come from the Broadsheet design system's
`styles.css` token sheet (see Design tokens); prefer its `var(--*)` tokens and its
`.btn` / `.tag` / `.input` classes over re-deriving the literals below.

---

## Screens / views

Shared shell: `width: 400px; height: 566px; background: #f3f2f2;`
`border: 1px solid rgba(32,30,29,.18); overflow: hidden; position: relative;`
`display: flex; flex-direction: column`. All three views fill the shell
(`height:100%`, column flex); the confirm sheet is absolutely positioned over
whichever view is showing. In the real extension the border/shadow are the popup
window's own chrome — drop them and let the popup size itself (`width: 400px`, body
margin 0).

### 1. Library (default)

Purpose: pick a template and deploy it, or jump into editing.

Layout, top to bottom:

- **Header** — `padding: 16px 18px 10px`, `display:flex`, `align-items:baseline`,
  `justify-content:space-between`.
  - Kicker: `TWP Script Deployer` — 10px, `letter-spacing:.12em`, uppercase, `rgba(32,30,29,.55)`.
  - Title: `Library` — `h3`, 23px, `letter-spacing:-.02em`, `margin: 2px 0 0`.
  - Right: active-tab tag — `.tag.tag-accent`, text `clock.payrollservers.us`
    (from `chrome.tabs.query({active:true,currentWindow:true})`; show the host only).
- **Template list** — `padding: 0 18px`, `flex:1`, `overflow:auto`. One row per saved template:
  - `display:grid; grid-template-columns: 1fr auto; align-items:baseline; gap: 4px 12px;`
    `padding: 11px 10px 11px 12px; margin: 0 -10px 0 -12px; cursor:pointer;`
    `border-left: 3px solid <edge>; background: <bg>`.
  - Selected row: `background:#e9f8ff` (`--color-accent-100`), `border-left-color:#0088b0`. Unselected: both `transparent`.
  - Name — 16.5px, `letter-spacing:-.01em`, underlined with
    `text-decoration-color: rgba(0,136,176,.4); text-underline-offset:3px`. Clicking the
    **name** opens the editor for that template; clicking elsewhere in the row only selects it.
  - Slot count, right-aligned — 11px, `letter-spacing:.06em`, uppercase, `rgba(32,30,29,.5)`, e.g. `3 slots`.
  - Second line (spans both columns) — 12.5px italic `rgba(32,30,29,.58)`: the filled
    page names with the trailing `Script` stripped, joined by ` · ` (e.g.
    `Round · Split · OTThreshold`). When none are filled: `no content yet`.
- **Action row** — `padding: 14px 18px 6px`, `display:flex`, `gap:10px`, `align-items:center`.
  - `Run routine` — `.btn.btn-primary`, `flex:1`, `min-height:40px`, `font-size:15px`. Opens the confirm sheet.
  - `Edit` — `.btn.btn-secondary`, `min-height:40px`. Opens the editor for the selected template.
  - `＋` — `.btn.btn-ghost`, `min-height:40px`, `title="New template"`. Opens the new-template view.
- **Footer line** — `padding: 4px 18px 16px`, 11.5px, `rgba(32,30,29,.45)`:
  `“<template name>” writes to <n> of 10 script pages`, where `<n>` is in `#006786`
  (`--color-accent-700`).

### 2. Template editor

Purpose: edit one template's script text, one page slot at a time.

- **Header** — `padding: 14px 16px 12px`, `display:flex`, `align-items:center`, `gap:10px`.
  - `←` back — `.btn.btn-ghost`, `min-height:28px`, `padding:0 6px`, `font-size:16px`, `title="Back to library"`.
  - Middle (`flex:1`): kicker `Template` (10px/.12em/uppercase/`rgba(32,30,29,.55)`) over the template name (17px, `letter-spacing:-.01em`).
  - `Save` — `.btn.btn-primary`, `min-height:32px`. Persists and returns to the library.
- **Body** — `display:grid; grid-template-columns: 150px 1fr;`
  `border-top: 1px solid rgba(32,30,29,.14); flex:1; min-height:0`.
  - **Rail** (150px) — `border-right: 1px solid rgba(32,30,29,.14); overflow-y:auto;`
    `overflow-x:hidden; padding: 6px 0`. One row per entry of `twpScriptPages`, in registry order:
    - `display:grid; grid-template-columns: 14px 1fr; gap:7px; align-items:baseline;`
      `padding: 7px 10px; cursor:pointer; background:<bg>`; active row `#e9f8ff`, else transparent.
    - Marker (14px column): `●` in `#0088b0` when that slot has non-blank content,
      otherwise the 1-based index zero-padded (`01`…`10`) in `rgba(32,30,29,.35)`;
      9px, `font-variant-numeric: tabular-nums`.
    - Label: the page label minus the trailing `Script` — 12.5px, `line-height:1.25`,
      `letter-spacing:-.005em`, `overflow-wrap:anywhere` (required: `SplitPostReportingDate`
      does not fit 150px unbroken). Active `#201e1d`, inactive `rgba(32,30,29,.72)`.
  - **Editor pane** — `padding: 12px 14px 14px; display:flex; flex-direction:column;`
    `gap:8px; min-height:0`.
    - Slot label — full page label (e.g. `RoundScript`), 14px, `letter-spacing:-.01em`.
    - Help line — 11px italic `rgba(32,30,29,.5)`: `Prepended to the page's script box`.
    - `textarea.input` — `font-family: ui-monospace, Menlo, monospace; font-size:12px;`
      `line-height:1.6; background:#f8f4f4; flex:1; min-height:0`, `spellcheck="false"`.
    - Meta row — `display:flex; justify-content:space-between`, 11px `rgba(32,30,29,.45)`:
      `<n> lines` (non-blank lines of the current slot) and `<n> of 10 filled`.

### 3. New template (from scratch)

Same two-column body as the editor; differences only:

- Header kicker `New template`, then `h3` `From scratch` — 20px, `letter-spacing:-.02em`, `margin: 1px 0 0`.
- `←` cancels back to the library and discards the draft.
- `Save` is `disabled` until the name is non-blank **and** at least one slot has content.
- **Name field** — `padding: 0 18px 12px`; `input.input`, `font-size:16px`,
  `letter-spacing:-.01em`, `background:#f8f4f4`,
  placeholder `Template name — e.g. Client 4412 Meal Rules`.
- Rail gets a header row: `Script pages` — `padding: 2px 10px 6px`, 10px, `.12em`, uppercase, `rgba(32,30,29,.5)`.
- Editor help line reads `Leave blank to skip this page`; textarea placeholder `Paste TWP script here`.
- Meta row left cell is a gating hint, in priority order:
  1. no name → `Name it to save`
  2. name but no content → `Fill at least one script page`
  3. otherwise → `Ready to save · deploys to <n> page` / `pages` (singular at 1)
  Right cell: `<n> of 10`.
- On save: create `{ id: crypto.randomUUID(), label: name.trim(), content }`, push to
  the custom-templates list in `chrome.storage.local` (`CUSTOM_TEMPLATES_KEY`), select
  it, return to the library.

### 4. Confirm / deploy sheet

Purpose: state exactly what will be written before anything touches TWP; then report progress.

- Backdrop — `position:absolute; inset:0; background: rgba(32,30,29,.42);`
  `display:flex; align-items:flex-end` (sheet rises from the bottom).
- Sheet — `background:#f3f2f2; width:100%; padding:18px;`
  `box-shadow: 0 -12px 32px rgba(45,43,43,.22)`.
- Kicker (10px/.12em/uppercase/`rgba(32,30,29,.55)`) and `h4` title (19px, `margin: 4px 0 12px`), by phase:
  | phase | kicker | title |
  | --- | --- | --- |
  | confirm | `Confirm deploy` | `“<name>” will change <n> pages` (curly quotes) |
  | running | `Deploying` | `Writing to TWP…` |
  | done | `Complete` | `All pages saved` |
- Row list — `display:flex; flex-direction:column; max-height:230px; overflow:auto`.
  One row per page **that has content** (skip blanks, same filter as `runRoutine`):
  `display:grid; grid-template-columns: 16px 1fr auto; gap:10px; align-items:baseline;`
  `padding: 8px 0; border-bottom: 1px solid rgba(32,30,29,.08)`.
  - Mark (13px) + note (11.5px `rgba(32,30,29,.5)`) by row state:
    | state | mark | mark color | note |
    | --- | --- | --- | --- |
    | pre-deploy | `+` | `#0088b0` | `<n> line` / `<n> lines` |
    | done | `✓` | `#0088b0` | `saved` |
    | in flight | `›` | `#d6006c` | `writing…` |
    | queued | `·` | `rgba(32,30,29,.35)` | `queued` |
  - Label (14px) — full page label.
- Actions — `display:flex; gap:10px; margin-top:16px`.
  - Primary (`.btn.btn-primary`, `flex:1`, `min-height:40px`): `Deploy now` → `Abort` → `Done`.
  - Ghost (`.btn.btn-ghost`, `min-height:40px`): `Cancel` before deploy, `Close` after it starts.

---

## Interactions & behavior

- **Navigation** is view swapping inside the one popup, no router: `library` ⇄ `editor`,
  `library` ⇄ `new`. Back/Save/Cancel always return to `library`.
- **Row click vs. name click** — the row selects; the name (the underlined text) opens
  the editor. Stop propagation on the name.
- **Deploy** — `Run routine` opens the sheet in `confirm` phase. `Deploy now` starts
  `runRoutine(template)`; rows advance one at a time. The prototype fakes this with an
  850 ms interval; in the extension drive it from real progress — mark a page `writing…`
  before `chrome.scripting.executeScript`, `saved` after its save postback, and surface a
  failed page as an error row instead of `saved` (`runRoutine` currently throws; consider
  catching per page so one failure doesn't strand the rest).
- **Abort** — mid-run, the primary button becomes `Abort`; it should stop before opening
  the next tab. Pages already saved stay saved; say so rather than implying a rollback.
- **Close** — closes the sheet and resets the phase. The Chrome popup unmounts when it
  loses focus, so persist run state (or run from the background worker) if a deploy
  should survive the popup closing.
- **Empty library** — not designed. Show the header, a one-line italic
  `rgba(32,30,29,.58)` note, and the `＋` action; ask before inventing more.
- **Transitions** — the prototype has none. If you add any, keep them under 160 ms and
  ease-out; the popup is opened to be used, not watched.
- **States on every control** come from the design system's `.btn` / `.input` classes:
  accent-ramp hover and pressed tints, `:focus-visible { outline: 2px solid #0088b0;
  outline-offset: 2px }`, disabled at 45% opacity. Do not restyle them.
- **Keyboard** — rail rows and template rows are `role="button" tabindex="0"` in the
  prototype but only wire `click`; add `Enter`/`Space` and arrow-key movement within the rail.

## State management

Popup-local (React `useState`), mirroring the prototype:

| state | type | notes |
| --- | --- | --- |
| `view` | `'library' \| 'editor' \| 'new'` | current view |
| `selectedTemplateId` | `string` | library selection; also the editor's subject |
| `activeSlotId` | `string` | which `twpScriptPages` entry the editor pane shows |
| `bodies` | `Record<templateId, Record<pageId, string>>` | edited script text, unsaved |
| `draft` | `{ name: string; content: Record<pageId,string>; activeSlotId: string }` | new-template view |
| `sheet` | `{ open: boolean; phase: 'confirm' \| 'running' \| 'done'; index: number }` | index = how many pages have finished |

Persistence (already in the repo): saved scripts under `SAVED_SCRIPTS_KEY`, custom
templates under `CUSTOM_TEMPLATES_KEY`, both in `chrome.storage.local`
(`src/scripts/storage.ts`). Built-in templates come from `twpScriptTemplates`
(`src/scripts/twp-script-content.ts`); the page registry from `twpScriptPages`
(`src/scripts/twp-pages.ts`). No fetching beyond `chrome.tabs.query` for the active-tab
tag. Note the current popup models a saved script as `{ id, templateId }` — a pointer to
a template; this design shows templates directly, so decide whether saved scripts remain
a separate concept or collapse into templates.

## Design tokens

From Broadsheet `styles.css` — use the variables, not the literals.

Color: `--color-bg #f3f2f2` · `--color-surface #eae9e9` · `--color-text #201e1d` ·
`--color-accent #0088b0` · `--color-accent-2 #d6006c` ·
`--color-divider rgba(32,30,29,.16)` · `--color-accent-100 #e9f8ff` ·
`--color-accent-700 #006786` · `--color-neutral-100 #f8f4f4` (the textarea/input ground) ·
`--color-neutral-300 #d7d3d3`. Ink at partial alpha is used for quiet text:
`.72` rail inactive, `.58` italic summaries, `.55` kickers, `.5` meta, `.45` footnotes,
`.35` empty markers. Cyan is the interactive color; magenta appears only as the
in-flight mark — never both accents in one small component.

Type: `--font-heading` / `--font-body` are both `"Source Serif 4", system-ui, sans-serif`
(headings 600). Sizes in use: 23 / 20 / 19 / 17 / 16.5 / 16 / 14 / 13 / 12.5 / 12 / 11.5 /
11 / 10 / 9 px. Headings carry `letter-spacing: -.02em`, body-size UI labels `-.01em`,
rail labels `-.005em`, kickers `+.12em` uppercase, the slot-count label `+.06em` uppercase.
Script text is `ui-monospace, Menlo, monospace` at 12px / 1.6.

Spacing: `--space-1..8` = 5 / 10 / 15 / 20 / 30 / 40 px. The popup's own paddings
(18px gutter, 14–16px header) sit between those steps because it is a 400px viewport,
not a page — keep them as written and don't tighten further.

Radius: `--radius-sm 1px`, `--radius-md 2px` (buttons, inputs), `--radius-lg 4px`.

Shadow: `--shadow-sm/md/lg`; the sheet uses an inverted lg
(`0 -12px 32px rgba(45,43,43,.22)`).

## Assets

None. No images, no icons — the marks (`●` `✓` `›` `·` `+` `←` `＋`) are text glyphs.
If you want real icons, the design system specifies Phosphor duotone; the extension
would need them vendored.

Fonts: Source Serif 4 via Google Fonts in the prototype. A Chrome extension cannot rely
on a remote font under a strict CSP — **vendor the WOFF2 files** into the extension and
`@font-face` them locally.

## Files

In this bundle:
- `TWP Deployer Mockups.dc.html` — the prototype (turn 3 = this design; turns 2 and 1 are history/before).
- `support.js` — the prototype's runtime. Required to open the HTML; not part of the design.

The design references Broadsheet's `styles.css` and `_ds_bundle.js` by relative path
(`_ds/broadsheet-…/`), which are **not** in this bundle — the HTML will render unstyled
chrome without them. Every value it needs is written out above.

In the extension repo, the code to change:
- `src/popup/App.tsx` — shell, active-tab query.
- `src/popup/ScriptLibrary.tsx` — becomes the library view.
- `src/popup/TemplateEditor.tsx` — becomes the editor + new-template views.
- `src/popup/App.css` — replaced by the tokens above.
Unchanged: `src/scripts/*` (`run-routine.ts`, `twp-pages.ts`, `twp-script-content.ts`,
`storage.ts`, `types.ts`).
